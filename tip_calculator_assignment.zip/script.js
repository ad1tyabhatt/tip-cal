let tipAmount = 0;
let total = 0;

let getBill = document.getElementById('#bill');
console.log(getBill)